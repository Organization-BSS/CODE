//
//  TimeView.h
//  MyUITabbarController
//
//  Created by bss on 16/8/30.
//  Copyright © 2016年 Beijing Galaxy Hangduoduo Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeView : UIView

@end
